/***************************************************************
 * (c) copyright 2026 - 2030, Honor.Runtime
 * All Rights Reserved.
 * -------------------------------------------------------------
 * filename:  FileFragmentForWebGLManager.cs
 * author:    云毅
 * created:   2026
 * descrip:   WebGL 专用持久化存储管理器（PlayerPrefs + AES + GZip）
 ***************************************************************/

using System;
using System.Collections.Generic;
using UnityEngine;

namespace Honor.Runtime
{
    /// <summary>
    /// WebGL 专用文件片段存储管理器
    /// 基于 PlayerPrefs 实现，支持 AES 加密 + GZip 压缩
    /// 提供分类管理、键值存储、增删改查
    /// </summary>
    public sealed partial class FileFragmentForWebGLManager
    {
        #region 构造 & 生命周期
        public FileFragmentForWebGLManager()
        {
            m_ItemNameGroups = new SortedDictionary<string, List<string>>();
        }

        /// <summary>
        /// 加载所有条目索引（从 PlayerPrefs 读取分类与键名）
        /// </summary>
        /// <returns>固定返回 true</returns>
        public bool Load()
        {
            // 从存档中读取所有条目
            LoadItemNameGroups();
            return true;
        }

        /// <summary>
        /// 立即保存到本地（调用 PlayerPrefs.Save）
        /// </summary>
        /// <returns>固定返回 true</returns>
        public bool Save()
        {
            PlayerPrefs.Save();
            return true;
        }
        #endregion

        #region 数据查询
        /// <summary>
        /// 获取指定分类下所有键名（数组）
        /// </summary>
        /// <param name="classifyName">分类名</param>
        /// <returns>键名数组</returns>
        public string[] GetAllItemNames(string classifyName)
        {
            List<string> range = null;
            if (m_ItemNameGroups.TryGetValue(classifyName, out range))
            {
                return range.ToArray();
            }
            return null;
        }

        /// <summary>
        /// 获取指定分类下所有键名（列表）
        /// </summary>
        /// <param name="classifyName">分类名</param>
        /// <param name="results">输出结果列表</param>
        public void GetAllItemNames(string classifyName, List<string> results)
        {
            if (results == null)
            {
                throw new Exception("Results 无效。");
            }

            results.Clear();

            List<string> range = null;
            if (m_ItemNameGroups.TryGetValue(classifyName, out range))
            {
                results = range;
            }

            return;
        }

        /// <summary>
        /// 判断是否存在某条数据
        /// </summary>
        /// <param name="classifyName">分类名</param>
        /// <param name="itemName">键名</param>
        /// <returns>是否存在</returns>
        public bool HasItem(string classifyName, string itemName)
        {
            string key = $"{classifyName}_{itemName}";
            return PlayerPrefs.HasKey(key);
        }
        #endregion

        #region 删除操作
        /// <summary>
        /// 删除单条数据（同步删除索引）
        /// </summary>
        /// <param name="classifyName">分类名</param>
        /// <param name="itemName">键名</param>
        /// <returns>是否删除成功</returns>
        public bool RemoveItem(string classifyName, string itemName)
        {
            string key = $"{classifyName}_{itemName}";
            if (!PlayerPrefs.HasKey(key))
            {
                return false;
            }

            PlayerPrefs.DeleteKey(key);

            if (m_ItemNameGroups.ContainsKey(classifyName))
            {
                if (m_ItemNameGroups[classifyName].Contains(itemName))
                {
                    m_ItemNameGroups[classifyName].Remove(itemName);
                    if (m_ItemNameGroups[classifyName].Count == 0)
                    {
                        m_ItemNameGroups.Remove(classifyName);
                    }
                }
            }

            RefreshItemNameListToSave(classifyName);
            RefreshClassifyNameListToSave();

            return true;
        }

        /// <summary>
        /// 清空数据（支持清空全部 / 清空指定分类）
        /// </summary>
        /// <param name="classifyName">分类名（null 则清空全部）</param>
        public void RemoveAllItems(string classifyName)
        {
            if (string.IsNullOrEmpty(classifyName))
            {
                List<string> classifyNames = new List<string>(m_ItemNameGroups.Keys);
                for(int index = 0; index < classifyNames.Count; index++)
                {
                    classifyName = classifyNames[index];
                    List<string> range = null;
                    if (m_ItemNameGroups.TryGetValue(classifyName, out range))
                    {
                        List<string> names = new List<string>();
                        foreach (var name in range)
                        {
                            string key = $"{classifyName}_{name}";
                            PlayerPrefs.DeleteKey(key);
                            names.Add(name);
                        }
                        names.ForEach((name) => { m_ItemNameGroups[classifyName].Remove(name); });

                        if (m_ItemNameGroups[classifyName].Count == 0)
                        {
                            m_ItemNameGroups.Remove(classifyName);
                        }

                    }
                }

                m_ItemNameGroups.Clear();
                RefreshItemNameListToSave(null);
                RefreshClassifyNameListToSave();
            }
            else
            {
                List<string> range = null;
                if (m_ItemNameGroups.TryGetValue(classifyName, out range))
                {
                    List<string> names = new List<string>();
                    foreach (var name in range)
                    {
                        string key = $"{classifyName}_{name}";
                        PlayerPrefs.DeleteKey(key);
                        names.Add(name);
                    }
                    names.ForEach((name) => { m_ItemNameGroups[classifyName].Remove(name); });

                    if (m_ItemNameGroups[classifyName].Count == 0)
                    {
                        m_ItemNameGroups.Remove(classifyName);
                    }

                    RefreshItemNameListToSave(classifyName);
                    RefreshClassifyNameListToSave();
                }
            }
        }
        #endregion

        #region Bool 存取
        /// <summary>
        /// 从指定条目中读取布尔值。
        /// </summary>
        public bool GetBool(string classifyName, string itemName)
        {
            string key = $"{classifyName}_{itemName}";
            return bool.Parse(GZip.UncompressFromBase64(AESEncrypt.DecodeFromBase64(PlayerPrefs.GetString(key))));
        }

        /// <summary>
        /// 从指定条目中读取布尔值。
        /// </summary>
        public bool GetBool(string classifyName, string itemName, bool defaultValue)
        {
            string key = $"{classifyName}_{itemName}";
            return bool.Parse(GZip.UncompressFromBase64(AESEncrypt.DecodeFromBase64(PlayerPrefs.GetString(key, AESEncrypt.EncodeToBase64(GZip.CompressToBase64(defaultValue.ToString()))))));
        }

        /// <summary>
        /// 向指定条目写入布尔值。
        /// </summary>
        public void SetBool(string classifyName, string itemName, bool value)
        {
            string key = $"{classifyName}_{itemName}";
            PlayerPrefs.SetString(key, AESEncrypt.EncodeToBase64(GZip.CompressToBase64(value.ToString())));

            bool modified = false;
            if (!m_ItemNameGroups.ContainsKey(classifyName))
            {
                m_ItemNameGroups.Add(classifyName, new List<string>());
                modified = true;
            }
            if (!m_ItemNameGroups[classifyName].Contains(itemName))
            {
                m_ItemNameGroups[classifyName].Add(itemName);
                modified = true;
            }

            if (modified)
            {
                RefreshItemNameListToSave(classifyName);
                RefreshClassifyNameListToSave();
            }
        }
        #endregion

        #region Int 存取
        /// <summary>
        /// 从指定条目中读取整数值。
        /// </summary>
        public int GetInt(string classifyName, string itemName)
        {
            string key = $"{classifyName}_{itemName}";
            return int.Parse(GZip.UncompressFromBase64(AESEncrypt.DecodeFromBase64(PlayerPrefs.GetString(key))));
        }

        /// <summary>
        /// 从指定条目中读取整数值。
        /// </summary>
        public int GetInt(string classifyName, string itemName, int defaultValue)
        {
            string key = $"{classifyName}_{itemName}";
            return int.Parse(GZip.UncompressFromBase64(AESEncrypt.DecodeFromBase64(PlayerPrefs.GetString(key, AESEncrypt.EncodeToBase64(GZip.CompressToBase64(defaultValue.ToString()))))));
        }

        /// <summary>
        /// 向指定条目写入整数值。
        /// </summary>
        public void SetInt(string classifyName, string itemName, int value)
        {
            string key = $"{classifyName}_{itemName}";
            PlayerPrefs.SetString(key, AESEncrypt.EncodeToBase64(GZip.CompressToBase64(value.ToString())));

            bool modified = false;
            if (!m_ItemNameGroups.ContainsKey(classifyName))
            {
                m_ItemNameGroups.Add(classifyName, new List<string>());
                modified = true;
            }
            if (!m_ItemNameGroups[classifyName].Contains(itemName))
            {
                m_ItemNameGroups[classifyName].Add(itemName);
                modified = true;
            }

            if (modified)
            {
                RefreshItemNameListToSave(classifyName);
                RefreshClassifyNameListToSave();
            }
        }
        #endregion

        #region Float 存取
        /// <summary>
        /// 从指定条目中读取浮点数值。
        /// </summary>
        public float GetFloat(string classifyName, string itemName)
        {
            string key = $"{classifyName}_{itemName}";
            return float.Parse(GZip.UncompressFromBase64(AESEncrypt.DecodeFromBase64(PlayerPrefs.GetString(key))));
        }

        /// <summary>
        /// 从指定条目中读取浮点数值。
        /// </summary>
        public float GetFloat(string classifyName, string itemName, float defaultValue)
        {
            string key = $"{classifyName}_{itemName}";
            return float.Parse(GZip.UncompressFromBase64(AESEncrypt.DecodeFromBase64(PlayerPrefs.GetString(key, AESEncrypt.EncodeToBase64(GZip.CompressToBase64(defaultValue.ToString()))))));
        }

        /// <summary>
        /// 向指定条目写入浮点数值。
        /// </summary>
        public void SetFloat(string classifyName, string itemName, float value)
        {
            string key = $"{classifyName}_{itemName}";
            PlayerPrefs.SetString(key, AESEncrypt.EncodeToBase64(GZip.CompressToBase64(value.ToString())));

            bool modified = false;
            if (!m_ItemNameGroups.ContainsKey(classifyName))
            {
                m_ItemNameGroups.Add(classifyName, new List<string>());
                modified = true;
            }
            if (!m_ItemNameGroups[classifyName].Contains(itemName))
            {
                m_ItemNameGroups[classifyName].Add(itemName);
                modified = true;
            }

            if (modified)
            {
                RefreshItemNameListToSave(classifyName);
                RefreshClassifyNameListToSave();
            }
        }
        #endregion

        #region String 存取
        /// <summary>
        /// 从指定条目中读取字符串值。
        /// </summary>
        public string GetString(string classifyName, string itemName)
        {
            string key = $"{classifyName}_{itemName}";
            return GZip.UncompressFromBase64(AESEncrypt.DecodeFromBase64(PlayerPrefs.GetString(key)));
        }

        /// <summary>
        /// 从指定条目中读取字符串值。
        /// </summary>
        public string GetString(string classifyName, string itemName, string defaultValue)
        {
            string key = $"{classifyName}_{itemName}";
            return GZip.UncompressFromBase64(AESEncrypt.DecodeFromBase64(PlayerPrefs.GetString(key, AESEncrypt.EncodeToBase64(GZip.CompressToBase64(defaultValue)))));
        }

        /// <summary>
        /// 向指定条目写入字符串值。
        /// </summary>
        public void SetString(string classifyName, string itemName, string value)
        {
            string key = $"{classifyName}_{itemName}";
            PlayerPrefs.SetString(key, AESEncrypt.EncodeToBase64(GZip.CompressToBase64(value)));
            
            bool modified = false;
            if (!m_ItemNameGroups.ContainsKey(classifyName))
            {
                m_ItemNameGroups.Add(classifyName, new List<string>());
                modified = true;
            }
            if (!m_ItemNameGroups[classifyName].Contains(itemName))
            {
                m_ItemNameGroups[classifyName].Add(itemName);
                modified = true;
            }

            if (modified)
            {
                RefreshItemNameListToSave(classifyName);
                RefreshClassifyNameListToSave();
            }
        }
        #endregion

        #region 调试方法
        /// <summary>
        /// 调试：打印所有分类与键名索引（方便排查存储问题）
        /// </summary>
        public void PrintAllNameLists()
        {
            string classifyAllNameList = AESEncrypt.DecodeFromBase64(PlayerPrefs.GetString("ClassifyNameListForWebGL"));
            Log.Info($"ClassifyNameListFoWebGL = {classifyAllNameList}");
            if (!string.IsNullOrEmpty(classifyAllNameList))
            {
                string[] classifyNameList = classifyAllNameList.Split(',');
                for (int classifyNameIndex = 0; classifyNameIndex < classifyNameList.Length; classifyNameIndex++)
                {
                    string classifyName = classifyNameList[classifyNameIndex];
                    string classifyXXXXXNameListText = AESEncrypt.DecodeFromBase64(PlayerPrefs.GetString($"Classify_{classifyName}_ItemNameListForWebGL", AESEncrypt.EncodeToBase64(string.Empty)));
                    Log.Info($"Classify_{classifyName}_ItemNameListForWebGL = {classifyXXXXXNameListText}");
                }
            }
        }
        #endregion

    
    }
}