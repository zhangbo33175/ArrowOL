/***************************************************************
 * (c) copyright 2026 - 2030, Honor.Runtime
 * All Rights Reserved.
 * -------------------------------------------------------------
 * filename:  LuaBTAction.cs
 * author:    云毅
 * created:   2026
 * descrip:   行为树自定义Lua Action节点，全生命周期转发到Lua层
 ***************************************************************/
using Honor.Runtime;
using UnityEngine;
using XLua;

#if BEHAVIOR_DESIGNER_ENABLE


namespace BehaviorDesigner.Runtime.Tasks
{
    /// <summary>
    /// Honor自定义Lua层行为树Action节点组件
    /// 该组件在合适的时机将自动触发行为树节点的生命周期函数与各种回调到Lua脚本中，
    /// 以确保行为树节点的逻辑通过调度Lua层代码及时完成。
    /// </summary>
    public partial class LuaBTAction : Action
    {
        [Tooltip("Lua行为树节点名称")]
        public string m_LuaBTActionName = string.Empty;

        private LuaBehaviour m_LuaBehaviour;
        private LuaTable m_LuaClass;

        #region Lua 回调函数缓存
        private LuaFunction m_OnAwakeBT;
        private LuaFunction m_OnStartBT;
        private LuaFunction m_OnUpdateBT;
        private LuaFunction m_OnPauseBT;
        private LuaFunction m_OnResetBT;
        private LuaFunction m_OnEndBT;
        private LuaFunction m_OnFixedUpdateBT;
        private LuaFunction m_OnLateUpdateBT;
        private LuaFunction m_OnBehaviorCompleteBT;
        private LuaFunction m_OnBehaviorRestartBT;
        private LuaFunction m_GetPriorityBT;
        private LuaFunction m_GetUtilityBT;
        private LuaFunction m_OnAnimatorIKBT;
        private LuaFunction m_OnCollisionEnterBT;
        private LuaFunction m_OnCollisionEnter2DBT;
        private LuaFunction m_OnCollisionExitBT;
        private LuaFunction m_OnCollisionExit2DBT;
        private LuaFunction m_OnConditionalAbort0BT;
        private LuaFunction m_OnControllerColliderHitBT;
        private LuaFunction m_OnDrawGizmosBT;
        private LuaFunction m_OnDrawNodeTextBT;
        private LuaFunction m_OnTriggerEnterBT;
        private LuaFunction m_OnTriggerEnter2DBT;
        private LuaFunction m_OnTriggerExitBT;
        private LuaFunction m_OnTriggerExit2DBT;
        #endregion

        #region 生命周期
        /// <summary>
        /// 行为树节点唤醒
        /// </summary>
        public override void OnAwake()
        {
            if (m_LuaBehaviour == null)
            {
                m_LuaBehaviour = gameObject.GetComponent<LuaBehaviour>();
            }
            
            // 初始化LuaBTAction并绑定Lua层对应生命周期函数与回调方法
            if (m_LuaBehaviour != null)
            {
                LuaFunction createBTAction;
                m_LuaBehaviour.luaClass.Get("CreateBTAction", out createBTAction);

                LuaTable args = Root.Lua.Env.NewTable();
                args.Set("luaBTName", m_LuaBTActionName);
                args.Set("csClass", this);

                m_LuaClass = createBTAction.Func<LuaTable, LuaTable, LuaTable>(m_LuaBehaviour.luaClass, args);
                if(m_LuaClass == null)
                {
                    Honor.Runtime.Log.Fatal("行为树Lua脚本：{0} 创建失败。", m_LuaBTActionName);
                    return;
                }

                m_LuaClass.Get("OnAwakeBT", out m_OnAwakeBT);
                m_LuaClass.Get("OnStartBT", out m_OnStartBT);
                m_LuaClass.Get("OnUpdateBT", out m_OnUpdateBT);
                m_LuaClass.Get("OnPauseBT", out m_OnPauseBT);
                m_LuaClass.Get("OnResetBT", out m_OnResetBT);
                m_LuaClass.Get("OnEndBT", out m_OnEndBT);
                m_LuaClass.Get("OnFixedUpdateBT", out m_OnFixedUpdateBT);
                m_LuaClass.Get("OnLateUpdateBT", out m_OnLateUpdateBT);
                m_LuaClass.Get("OnBehaviorCompleteBT", out m_OnBehaviorCompleteBT);
                m_LuaClass.Get("OnBehaviorRestartBT", out m_OnBehaviorRestartBT);
                m_LuaClass.Get("GetPriorityBT", out m_GetPriorityBT);
                m_LuaClass.Get("GetUtilityBT", out m_GetUtilityBT);
                m_LuaClass.Get("OnAnimatorIKBT", out m_OnAnimatorIKBT);
                m_LuaClass.Get("OnCollisionEnterBT", out m_OnCollisionEnterBT);
                m_LuaClass.Get("OnCollisionEnter2DBT", out m_OnCollisionEnter2DBT);
                m_LuaClass.Get("OnCollisionExitBT", out m_OnCollisionExitBT);
                m_LuaClass.Get("OnCollisionExit2DBT", out m_OnCollisionExit2DBT);
                m_LuaClass.Get("OnConditionalAbort0BT", out m_OnConditionalAbort0BT);
                m_LuaClass.Get("OnControllerColliderHitBT", out m_OnControllerColliderHitBT);
                m_LuaClass.Get("OnDrawGizmosBT", out m_OnDrawGizmosBT);
                m_LuaClass.Get("OnDrawNodeTextBT", out m_OnDrawNodeTextBT);
                m_LuaClass.Get("OnTriggerEnterBT", out m_OnTriggerEnterBT);
                m_LuaClass.Get("OnTriggerEnter2DBT", out m_OnTriggerEnter2DBT);
                m_LuaClass.Get("OnTriggerExitBT", out m_OnTriggerExitBT);
                m_LuaClass.Get("OnTriggerExit2DBT", out m_OnTriggerExit2DBT);
            }

            if(m_OnAwakeBT != null)
            {
                m_OnAwakeBT.Action(m_LuaClass);
            }
            else
            {
                base.OnAwake();
            }
        }

        /// <summary>
        /// 节点开始执行
        /// </summary>
        public override void OnStart()
        {
            if (m_OnStartBT != null)
            {
                m_OnStartBT.Action(m_LuaClass);
            }
            else
            {
                base.OnStart();
            }
        }

        /// <summary>
        /// 节点每帧更新
        /// </summary>
        public override TaskStatus OnUpdate()
        {
            if (m_OnUpdateBT != null)
            {
                return m_OnUpdateBT.Func<LuaTable, TaskStatus>(m_LuaClass);
            }
            return base.OnUpdate();
        }

        /// <summary>
        /// 节点暂停
        /// </summary>
        public override void OnPause(bool paused)
        {
            if (m_OnPauseBT != null)
            {
                m_OnPauseBT.Action(m_LuaClass, paused);
            }
            else
            {
                base.OnPause(paused);
            }
        }

        /// <summary>
        /// 节点重置
        /// </summary>
        public override void OnReset()
        {
            if (m_OnResetBT != null)
            {
                m_OnResetBT.Action(m_LuaClass);
            }
            else
            {
                base.OnReset();
            }
        }

        /// <summary>
        /// 节点结束
        /// </summary>
        public override void OnEnd()
        {
            if (m_OnEndBT != null)
            {
                m_OnEndBT.Action(m_LuaClass);
            }
            else
            {
                base.OnEnd();
            }
        }
        #endregion

        #region 定时更新
        /// <summary>
        /// 物理帧更新
        /// </summary>
        public override void OnFixedUpdate()
        {
            if (m_OnFixedUpdateBT != null)
            {
                m_OnFixedUpdateBT.Action(m_LuaClass);
            }
            else
            {
                base.OnFixedUpdate();
            }
        }

        /// <summary>
        /// 延迟帧更新
        /// </summary>
        public override void OnLateUpdate()
        {
            if (m_OnLateUpdateBT != null)
            {
                m_OnLateUpdateBT.Action(m_LuaClass);
            }
            else
            {
                base.OnLateUpdate();
            }
        }
        #endregion

        #region 行为树全局事件
        /// <summary>
        /// 行为树执行完成
        /// </summary>
        public override void OnBehaviorComplete()
        {
            if (m_OnBehaviorCompleteBT != null)
            {
                m_OnBehaviorCompleteBT.Action(m_LuaClass);
            }
            else
            {
                base.OnBehaviorComplete();
            }
        }

        /// <summary>
        /// 行为树重启
        /// </summary>
        public override void OnBehaviorRestart()
        {
            if (m_OnBehaviorRestartBT != null)
            {
                m_OnBehaviorRestartBT.Action(m_LuaClass);
            }
            else
            {
                base.OnBehaviorRestart();
            }
        }
        #endregion

        #region 优先级与决策
        /// <summary>
        /// 获取节点优先级
        /// </summary>
        public override float GetPriority()
        {
            if (m_GetPriorityBT != null)
            {
                return m_GetPriorityBT.Func<LuaTable, float>(m_LuaClass);
            }
            return base.GetPriority();
        }

        /// <summary>
        /// 获取效用值
        /// </summary>
        public override float GetUtility()
        {
            if (m_GetUtilityBT != null)
            {
                return m_GetUtilityBT.Func<LuaTable, float>(m_LuaClass);
            }
            return base.GetUtility();
        }
        #endregion

        #region 动画与物理回调
        /// <summary>
        /// 动画IK回调
        /// </summary>
        public override void OnAnimatorIK()
        {
            if (m_OnAnimatorIKBT != null)
            {
                m_OnAnimatorIKBT.Action(m_LuaClass);
            }
            else
            {
                base.OnAnimatorIK();
            }
        }

        /// <summary>
        /// 3D碰撞进入
        /// </summary>
        public override void OnCollisionEnter(Collision collision)
        {
            if (m_OnCollisionEnterBT != null)
            {
                m_OnCollisionEnterBT.Action(m_LuaClass, collision);
            }
            else
            {
                base.OnCollisionEnter(collision);
            }
        }

        /// <summary>
        /// 2D碰撞进入
        /// </summary>
        public override void OnCollisionEnter2D(Collision2D collision)
        {
            if (m_OnCollisionEnter2DBT != null)
            {
                m_OnCollisionEnter2DBT.Action(m_LuaClass, collision);
            }
            else
            {
                base.OnCollisionEnter2D(collision);
            }
        }

        /// <summary>
        /// 3D碰撞退出
        /// </summary>
        public override void OnCollisionExit(Collision collision)
        {
            if (m_OnCollisionExitBT != null)
            {
                m_OnCollisionExitBT.Action(m_LuaClass, collision);
            }
            else
            {
                base.OnCollisionExit(collision);
            }
        }

        /// <summary>
        /// 2D碰撞退出
        /// </summary>
        public override void OnCollisionExit2D(Collision2D collision)
        {
            if (m_OnCollisionExit2DBT != null)
            {
                m_OnCollisionExit2DBT.Action(m_LuaClass, collision);
            }
            else
            {
                base.OnCollisionExit2D(collision);
            }
        }

        /// <summary>
        /// 条件中断
        /// </summary>
        public override void OnConditionalAbort()
        {
            if (m_OnConditionalAbort0BT != null)
            {
                m_OnConditionalAbort0BT.Action(m_LuaClass);
            }
            else
            {
                base.OnConditionalAbort();
            }
        }

        /// <summary>
        /// 控制器碰撞
        /// </summary>
        public override void OnControllerColliderHit(ControllerColliderHit hit)
        {
            if (m_OnControllerColliderHitBT != null)
            {
                m_OnControllerColliderHitBT.Action(m_LuaClass, hit);
            }
            else
            {
                base.OnControllerColliderHit(hit);
            }
        }
        #endregion

        #region 触发与绘制
        /// <summary>
        /// 3D触发进入
        /// </summary>
        public override void OnTriggerEnter(Collider other)
        {
            if (m_OnTriggerEnterBT != null)
            {
                m_OnTriggerEnterBT.Action(m_LuaClass, other);
            }
            else
            {
                base.OnTriggerEnter(other);
            }
        }

        /// <summary>
        /// 2D触发进入
        /// </summary>
        public override void OnTriggerEnter2D(Collider2D other)
        {
            if (m_OnTriggerEnter2DBT != null)
            {
                m_OnTriggerEnter2DBT.Action(m_LuaClass, other);
            }
            else
            {
                base.OnTriggerEnter2D(other);
            }
        }

        /// <summary>
        /// 3D触发退出
        /// </summary>
        public override void OnTriggerExit(Collider other)
        {
            if (m_OnTriggerExitBT != null)
            {
                m_OnTriggerExitBT.Action(m_LuaClass, other);
            }
            else
            {
                base.OnTriggerExit(other);
            }
        }

        /// <summary>
        /// 2D触发退出
        /// </summary>
        public override void OnTriggerExit2D(Collider2D other)
        {
            if (m_OnTriggerExit2DBT != null)
            {
                m_OnTriggerExit2DBT.Action(m_LuaClass, other);
            }
            else
            {
                base.OnTriggerExit2D(other);
            }
        }

        /// <summary>
        /// Gizmos 绘制
        /// </summary>
        public override void OnDrawGizmos()
        {
            if (m_OnDrawGizmosBT != null)
            {
                m_OnDrawGizmosBT.Action(m_LuaClass);
            }
            else
            {
                base.OnDrawGizmos();
            }
        }

        /// <summary>
        /// 节点文本绘制
        /// </summary>
        public override string OnDrawNodeText()
        {
            if (m_OnDrawNodeTextBT != null)
            {
                return m_OnDrawNodeTextBT.Func<LuaTable, string>(m_LuaClass);
            }
            return base.OnDrawNodeText();
        }
        #endregion
    }
}

#endif